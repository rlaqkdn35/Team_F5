// AiPicksPageLayout.jsx (예시)
import React from 'react';
import { Outlet } from 'react-router-dom';
import SubNavigation from '../../components/common/SubNavigation/SubNavigation.jsx';
import './AiPicksPageLayout.css';
const aiPicksSubNavLinks = [
  { name: '홈', path: '/ai-picks' },
  { name: '오늘의 종목', path: '/ai-picks/today' },
  { name: '추천', path: '/ai-picks/recommendations' },
];

const AiPicksPageLayout = () => {
  return (
    <div className="ai-picks-page-layout">
      <SubNavigation links={aiPicksSubNavLinks} basePath="/ai-picks" />
      <div className="page-content-area"> {/* 이 클래스는 App.css 등에서 패딩 등을 정의 */}
        <Outlet />
      </div>
    </div>
  );
};
export default AiPicksPageLayout;

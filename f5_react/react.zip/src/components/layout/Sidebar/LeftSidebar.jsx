import React from 'react';
import { NavLink } from 'react-router-dom'; // NavLink로 활성 링크 스타일링
import './LeftSidebar.css';


const Sidebar = () => {
  return (
    <aside className="app-left-sidebar">

    </aside>
  );
};

export default Sidebar;
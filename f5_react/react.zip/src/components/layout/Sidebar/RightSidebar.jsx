import React from 'react';
import './RightSidebar.css'; // RightSidebar 스타일

const RightSidebar = () => {
  return (
    <aside className="app-right-sidebar">
      {/* 현재는 아무 내용 없음. 필요시 추후 내용 추가 */}
      {/* <p>오른쪽 사이드바</p> */}
    </aside>
  );
};

export default RightSidebar;